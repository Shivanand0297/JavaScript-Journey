// Showing Call Stack
/*
var name = "Anurag";
var lastname = "Tiwari";
function fullname() {
  var company = "ineuron";
  return company;
}
console.log(name);
var funName = fullname();
console.log(funName);

*/
// Code to show Scope chainning
/*
function a() {
  var b = 10;
  function c() {
    console.log(b);
  }
  c();
}
a();

*/

// Let var and Const
// console.log(a);
let a = 10;
console.log(a);
var b = 16;
