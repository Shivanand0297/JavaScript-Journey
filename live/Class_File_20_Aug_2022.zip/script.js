// Program for user Reg.
// let userName = "learncodeonline";
// let full_Name = "Anurag";
// const eMail = "qwerty@gmail.com";
// let Phone_Num = 1234567890;
// let pass = "qwer";

// console.log(typeof Phone_Num);

// console.log("My username is " + userName + " My Mobile Number is" + Phone_Num);

// console.log(`
// My User Name : ${userName},
//     My Mobile Number is: ${Phone_Num}
// `);

// Operators
// let value1 = 25;
// let value2 = 4;

// let result = value1 % value2;
// console.log(result);

// let mrp = 1999;
// let discprice = 699;
// console.log("The MRP of item is " + mrp);
// let DPrice = ((mrp - discprice) / mrp) * 100;
// console.log("The Discounted Percentage is " + DPrice);
// let roundprice = Math.round(DPrice);
// console.log("The Discounted percentage is " + roundprice);

// let an = null;
// console.log(typeof an);

// let ab = 5;
// let abc = ab++;
// console.log(abc);

let var1 = 7;
let var2 = "7";
