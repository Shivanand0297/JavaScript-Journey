// let user = "trial";

// switch (user) {
//   case "admin":
//     console.log("You are admin");
//     break;
//   case "student":
//     console.log("You are Student");
//     break;
//   default:
//     console.log("YOu are Trial user");
// }
// console.log("SWitch Case Complete");

// // Array
// let Arr1 = ["Hitesh sir", "Anirudh", "Prasad", "Surya"];
// console.log(Arr1);
// console.log(Arr1.length);
// console.log(Arr1[Arr1.length - 1]);
// Arr1[3] = "Anurag";
// console.log(Arr1);

// let newarr = new Array("a", "b", "c");

// let Arr1 = ["Hitesh sir", "Anirudh", "Prasad", "Surya"];
// console.log(Arr1);
// Arr1.push("Anurag");
// console.log(Arr1);
// //Syntax: array.slice(startindex,endindex)
// let Arr2 = Arr1.slice(1, 4);
// console.log(Arr2);

// let nam = ["Ab", "bb", "Cc", "Dd", "Ee", "Dd", "Ee"];
// console.log(nam);
// // Syntax: array.splice(index,howmaytodelete,values)
// nam.splice(2, 2, "New Value 1", "New Value 2");
// console.log(nam);

// let nam = ["Ab", "bb", "Cc", "Dd", "Ee", "Dd", "Ee"];
// let nam1 = [1, 2, 3, 4, 5, 6];
// let nam2 = [7, 8, 9, 1];
// console.log(nam.concat(nam1, nam2));

// let aar1 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
// // Syn: array.copyWithin(target_index,start,end)
// console.log(aar1.copyWithin(1, 5, 8));

// let arr1 = [1, 2, 3, 4, 5, 6, 7, 8];
// Syn: array.includes(values,index)
// console.log(arr1.includes(5, 4)); //true

// let arr1 = [1, 2, 3, 4, 5, 6, "LCO", 8];
// console.log(arr1.indexOf("LCO"));

// MAP
let asqr = [1, 4, 9, 16];
//array.map(expr)
// console.log(asqr.map(Math.sqrt));
// console.log(asqr.reverse());

// console.log(asqr.shift());
// console.log(asqr);
// console.log(asqr.shift());
// console.log(asqr);

let names = [
  "Hitesh Sir",
  "Anurag",
  "Anirudh",
  "Prasad",
  "Surya Sir",
  "Sairaj",
];
// console.log(names.sort());

// console.log(names.toString());

// console.log(names.unshift("Vlaue 1"));
// console.log(names);

// let str = "javascript";
// let ar1 = str.split("");
// console.log(ar1);

const PI = Math.PI;
// console.log(PI);

// console.log(Math.round(PI));
// console.log(Math.floor(PI));
// console.log(Math.ceil(PI));

// console.log(Math.min(-25, 89, 23, 45, 67, 89, 19, 34, 56));

// let num = Math.random();
// let num1 = Math.random() * 11;

// console.log(num1);

// console.log(Math.abs(-10));
// console.log(Math.sqrt(196));
// console.log(Math.pow(3, 2));

// console.log(Math.cos(60));
